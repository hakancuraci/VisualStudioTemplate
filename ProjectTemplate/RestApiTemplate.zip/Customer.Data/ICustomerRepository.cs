﻿using System.Collections.Generic;

namespace $ext_safeprojectname$.Data
{
    public interface ICustomerRepository
    {
        List<string> GetAll();
    }
}
